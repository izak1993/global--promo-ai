# Global Promo AI — Starter MVP

Mobile-friendly web app / installable PWA starter. The first version generates promotional copy from built-in templates, saves drafts locally in the browser, and requires no API keys or paid services.

## Current limitations
- This is template-based content generation, not live generative AI.
- Drafts are stored only in the current browser/device.
- No accounts, cloud sync, database, real payment checkout, or subscription enforcement are included.
- Prices displayed are examples only; do not accept payments or promise paid access until a payment provider and server-side subscription checks are implemented.
- A service worker is included and attempts registration when served over HTTP/HTTPS; PWA/offline features require an appropriate secure origin (HTTPS or localhost).

## Test locally
Open `index.html` in a browser. Some PWA features require HTTPS or localhost.

## Publish free
1. Create a GitHub repository and upload `index.html`, `manifest.webmanifest`, and `sw.js`.
2. Enable GitHub Pages in repository settings, or connect the repository to Cloudflare Pages.
3. Use the generated HTTPS URL to test the site on Android Chrome.
4. In Chrome, use the menu and select `Install app` or `Add to Home screen` if offered.

## Before subscriptions
Implement authentication, database-backed customer campaigns, server-side usage/plan enforcement, payment provider onboarding and webhook verification, cancellation/refund workflows, privacy policy, terms, support contact, and abuse/cost limits. Confirm that your chosen provider can onboard a Kenya-based business and pay out in a usable way before building around it. Do not store secret API keys in frontend code.

## Validate demand first
Show the demo to 10–20 small businesses and ask which features they would pay for. The example $5 and $12 monthly prices are hypotheses, not proven market rates.
